
#include "arm_math.h"

void arm_radix8_butterfly_f32(
  float32_t * pSrc,
  uint16_t fftLen,
  const float32_t * pCoef,
  uint16_t twidCoefModifier)
{
    // Stub function for compatibility with arm_cfft_f32.c.
    // Does nothing in this stub; just here to satisfy linker.
    (void)pSrc;
    (void)fftLen;
    (void)pCoef;
    (void)twidCoefModifier;
}
